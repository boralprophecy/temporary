import os
from haystack import Finder
from haystack.database.sql import SQLDocumentStore
from haystack.indexing.cleaning import clean_wiki_text
from haystack.indexing.io import write_documents_to_db
from haystack.reader.transformers import TransformersReader
from haystack.retriever.tfidf import TfidfRetriever
from haystack.utils import print_answers
import pandas as pd

       

## Indexing & cleaning documents
def main():
    
    # Storing documents
    document_store = SQLDocumentStore(url="sqlite:///qa_v31.db")
    
    ## Initalize Reader, Retriever & Finder
    retriever = TfidfRetriever(document_store=document_store)
    
    # A reader scans the text chunks in detail and extracts the k best answers
    reader = TransformersReader(model="distilbert-base-uncased-distilled-squad", tokenizer="distilbert-base-uncased", use_gpu=-1)
    
    # The Finder sticks together retriever and retriever in a pipeline to answer our actual questions
    finder = Finder(reader, retriever)
    
    query_df = pd.read_csv( "question.csv" )

    # asking question    
    prediction = finder.get_answers(question=str( query_df['question'][0] ), top_k_retriever=2, top_k_reader=5)
    answer_df = print_answers(prediction, details="medium")
    answer_df.to_csv("answer_df.csv", encoding='utf-8', index=False)

if __name__ == '__main__':
    main()

